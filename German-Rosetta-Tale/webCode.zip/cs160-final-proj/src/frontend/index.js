/* eslint-disable quotes */
import React from 'react';
import ReactDOM from 'react-dom';
import App from './component/App/App.js';
import BookPage from './component/BookPage/BookPage';
import TeamPage from './component/TeamPage/TeamPage';
import { overrideComponentTypeChecker } from 'react-toolbox';
import { Router, Route, Link, IndexRoute, hashHistory, browserHistory } from 'react-router';

const rootEl = document.getElementById('app');
document.getElementById('app').style.height = "100%";
document.getElementById('app').style.width = "100%";

ReactDOM.render(
  <Router history={browserHistory}>
    <Route path="/" component={App}/>
    <Route path="/book" component={BookPage}/>
    <Route path="/team" component={TeamPage}/>
  </Router>,
  rootEl
);
