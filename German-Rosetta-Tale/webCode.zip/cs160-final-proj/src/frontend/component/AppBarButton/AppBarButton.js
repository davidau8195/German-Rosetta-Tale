/* eslint-disable eol-last */
/**
 * Created by jaesunglee on 05/05/2017.
 */
import React from 'react';
import { Button } from 'react-toolbox/lib/button';
import theme from './AppBarButton.css';

const AppBarButton = (props) => <Button {...props} theme={theme} />;
export default AppBarButton;