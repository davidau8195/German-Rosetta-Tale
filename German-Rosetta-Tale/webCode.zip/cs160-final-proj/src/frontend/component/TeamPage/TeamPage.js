/* eslint-disable eol-last,quotes,no-trailing-spaces */
/**
 * Created by jaesunglee on 06/05/2017.
 */
import React from 'react';
import AppBarButton from '../AppBarButton/AppBarButton';
import AppBar from 'react-toolbox/lib/app_bar';
import style from './TeamPage.css';
import ProgressBar from 'react-toolbox/lib/progress_bar';
import {Card, CardMedia, CardTitle, CardText, CardActions} from 'react-toolbox/lib/card';
import Link from 'react-toolbox/lib/link';

class TeamPage extends React.Component {

  constructor () {
    super();

    this.fetchTeamData = this.fetchTeamData.bind(this);

    this.state = {
      isInitialized: false,
      teamData: null
    };
  }

  componentDidMount() {
    this.fetchTeamData();
  }

  fetchTeamData () {
    fetch(`https://vegkc64dd5.execute-api.us-east-1.amazonaws.com/prod/BookWS?TableName=Team`,
      {
        mode: 'cors',
        method: 'GET'
      })
      .then(response => response.json())
      .then(json => {
        this.setState({teamData: json.Items, isInitialized: true});
      })
      .catch(err => {
        console.log(err);
      });
  }

  renderTeamMembers () {
    if (this.state.isInitialized && this.state.teamData) {
      const teamCards = this.state.teamData.map((member, idx) => {
        return (
          <Card key={idx}
                style={{width: '350px', margin: '20px'}}>
            <CardTitle
              title={member.Name}
            />
            <CardMedia
              aspectRatio="square"
              image={member.ImageURL}
            />
            <CardActions>
              <nav>
                <Link style={{textDecoration: 'none'}} href={member.LinkedInURL} label="LinkedIn" icon='person'/>
              </nav>
            </CardActions>
          </Card>
        );
      });
      return (
        <div className={style.contents}>
          {teamCards}
        </div>
      );
    } else {
      return (
        <div className={style.contents}>
          <ProgressBar className={style.progress}
                       type='circular'
                       mode='indeterminate'
                       multicolor/>
        </div>
      );
    }
  }

  render () {
    return (
      <div className={style.container}>
        <AppBar title='Berkeley Context Reader'>
          <AppBarButton icon="home" label="Main Menu" onClick=
              /* eslint-disable react/prop-types */
          /* eslint-disable quotes */
          {() => {
            this.props.router.push(`/`);
          }}/>
        </AppBar>
        {this.renderTeamMembers()}
      </div>
    );
  }
}

export default TeamPage;