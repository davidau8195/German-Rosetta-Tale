/* eslint-disable semi,quotes,react/prop-types */
import React from 'react';
import AppBar from 'react-toolbox/lib/app_bar';
import {Card, CardMedia, CardTitle, CardText, CardActions} from 'react-toolbox/lib/card';
import ProgressBar from 'react-toolbox/lib/progress_bar';
import Autocomplete from 'react-toolbox/lib/autocomplete';
import Dialog from 'react-toolbox/lib/dialog';
import AppBarButton from '../AppBarButton/AppBarButton';
import Button from 'react-toolbox/lib/button';
import style from './App.css';

class App extends React.Component {

  constructor () {
    super();

    this.fetchBooksMetaData = this.fetchBooksMetaData.bind(this);
    this.handleAutoComplete = this.handleAutoComplete.bind(this);

    this.state = {
      isInitialized: false,
      books: null,
      autoComplete: null
    };
  }

  componentDidMount () {
    this.fetchBooksMetaData();
  }

  handleAutoComplete (book) {
    console.log(book)
    this.props.router.push(`/book?name=${encodeURIComponent(book)}`);
  }

  fetchBooksMetaData () {
    fetch(`https://vegkc64dd5.execute-api.us-east-1.amazonaws.com/prod/BookWS?TableName=BookMetaData`,
      {
        mode: 'cors',
        method: 'GET'
      })
      .then(response => response.json())
      .then(json => {
        this.setState({books: json.Items});
      })
      .catch(err => {
        console.log(err);
      });
  }

  renderBooks () {
    if (!this.state.books) {
      return (
        <div className={style.contents}>
          <ProgressBar className={style.progress}
                       type='circular'
                       mode='indeterminate'
                       multicolor/>
        </div>
      );
    }
    this.bookNames = [];
    const bookCards = this.state.books.map((book, idx) => {
      this.bookNames.push(book.BookName);
      return (
        <Card key={idx}
              style={{width: '350px', margin: '20px'}}>
          <CardTitle
            avatar={book.ImageURL}
            title={book.BookName}
          />
          <CardMedia
            aspectRatio="square"
            image={book.ImageURL}
          />
          <CardText>{book.Summary}</CardText>
          <CardActions>
            <Button className={style.read_button} icon="book" label="Read" raised primary onClick=
                /* eslint-disable react/prop-types */
            {() => {
              this.props.router.push(`/book?name=${encodeURIComponent(book.BookName)}&image=${encodeURIComponent(book.ImageURL)}`);
            }}/>
          </CardActions>
        </Card>
      );
    });
    return (
      <div>
        <Autocomplete
          icon="search"
          className={style.search}
          direction="down"
          label="Search Books"
          source={this.bookNames}
          value={this.state.books}
          onChange={this.handleAutoComplete}
        />
        <div className={style.contents}>
          {bookCards}
        </div>
      </div>
    );
  }

  render () {
    return (
      <div className={style.container}>
        <AppBar title='Berkeley Context Reader'>
          <AppBarButton label="Meet the Team" onClick={() => {
            this.props.router.push(`/team`);
          }}/>
          <AppBarButton icon="add" label="Upload book"/>
        </AppBar>
        {this.renderBooks()}
      </div>
    )
  }
}

export default App;
