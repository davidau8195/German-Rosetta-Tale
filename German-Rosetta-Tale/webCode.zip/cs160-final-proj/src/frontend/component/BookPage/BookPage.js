/* eslint-disable quotes,react/prop-types */
/**
 * Created by jaesunglee on 05/05/2017.
 */
import React, {PropTypes} from 'react';
import AppBar from 'react-toolbox/lib/app_bar';
import ProgressBar from 'react-toolbox/lib/progress_bar';
import {Card, CardMedia, CardTitle, CardText, CardActions} from 'react-toolbox/lib/card';
import style from './BookPage.css';
import { List, ListItem, ListSubHeader, ListDivider, ListCheckbox } from 'react-toolbox/lib/list';
import Button from 'react-toolbox/lib/button';
import AppBarButton from '../AppBarButton/AppBarButton';

class BookPage extends React.Component {

  constructor () {
    super();

    this.fetchSentenceData = this.fetchSentenceData.bind(this);
    this.setSentenceData = this.setSentenceData.bind(this);
    this.onPrevSentenceClick = this.onPrevSentenceClick.bind(this);
    this.onNextSentenceClick = this.onNextSentenceClick.bind(this);
    this.onReadFromBeginningClick = this.onReadFromBeginningClick.bind(this);

    this.state = {
      isInitialized: false,
      sentenceIdx: 0,
      sentenceData: null,
      imageURL: null,
      bookTitle: null,
      isBookFinished: false
    };
  }

  componentDidMount () {
    this.fetchSentenceData();
  }

  onPrevSentenceClick() {
    const prevIdx = this.state.sentenceIdx - 2;
    if (prevIdx >= 0) {
      this.setState({isInitialized: false, sentenceData: null, sentenceIdx: prevIdx});
      this.fetchSentenceData();
    }
  }

  onNextSentenceClick() {
    if (this.state.sentenceIdx <= 2) {
      this.setState({isInitialized: false, sentenceData: null});
      this.fetchSentenceData();
    } else {
      this.setState({isBookFinished: true, isInitialized: false});
    }
  }

  onReadFromBeginningClick() {
    this.setState({isBookFinished: false, isInitialized: false, sentenceIdx: 0, sentenceData: null});
    this.fetchSentenceData();
  }

  fetchSentenceData () {
    this.setState({imageURL: this.props.location.query.image});
    fetch(`https://vegkc64dd5.execute-api.us-east-1.amazonaws.com/prod/BookWS?TableName=Books`,
      {
        mode: 'cors',
        method: 'GET'
      })
      .then(response => response.json())
      .then(json => {
        this.setSentenceData(json.Items, this.props.location.query.name, this.state.sentenceIdx);
      })
      .catch(err => {
        console.log(err);
      });
  }

  setSentenceData (books, targetName, targetIdx) {
    books.map(book => {
      if (book.BookTitle === targetName && book.SentenceIdx === targetIdx) {
        this.setState({sentenceData: book, isInitialized: true, sentenceIdx: book.SentenceIdx + 1, bookTitle: targetName});
      }
    });
  }

  renderBookPage () {
    if (this.state.isInitialized) {
      return (
        <div className={style.contents}>
          <Card style={{width: '80%'}}>
            <CardTitle
              avatar={this.state.imageURL}
              title={this.state.bookTitle}
            />
            <CardText style={{fontSize: '10px', fontStyle: 'italic'}}>You are currently reading sentence #{this.state.sentenceIdx}</CardText>
            <List>
              <ListSubHeader caption='Full English Sentence' />
              <ListItem
                avatar="https://cdn1.iconfinder.com/data/icons/flags-of-the-world-2/128/united-states-circle-512.png"
                caption={this.state.sentenceData.EnglishSentence}
              />
              <ListDivider />
              <ListSubHeader caption='One Word Replaced with German' />
              <ListItem
                avatar="https://cdn.countryflags.com/thumbs/germany/flag-round-250.png"
                caption={this.state.sentenceData.OneWordReplaced}
              />
              <ListDivider />
              <ListSubHeader caption='Two Words Replaced With German' />
              <ListItem
                avatar="https://cdn.countryflags.com/thumbs/germany/flag-round-250.png"
                caption={this.state.sentenceData.TwoWordsReplaced}
              />
              <ListDivider />
            </List>
            <CardText style={{fontSize: '15px', color: 'red'}}>{this.state.sentenceData.WordOne}</CardText>
            <CardText style={{fontSize: '15px', color: 'red'}}>{this.state.sentenceData.WordTwo}</CardText>
            <CardText style={{fontSize: '15px', color: 'red'}}>{this.state.sentenceData.WordThree}</CardText>
            <CardActions style={{display: 'flex', flexWrap: 'wrap', margin: '0 auto', alignItems: 'center', justifyContent: 'center'}}>
              <Button className={style.sentence_swipe_button} label="Previous Sentence" raised primary onClick={this.onPrevSentenceClick}/>
              <Button className={style.sentence_swipe_button} label="Next Sentence" raised primary onClick={this.onNextSentenceClick}/>
            </CardActions>
          </Card>
        </div>
      );
    } else if (this.state.isBookFinished) {
      return (
        <div className={style.contents}>
          <Card style={{width: '80%'}}>
            <CardTitle
              avatar={this.state.imageURL}
              title={this.state.bookTitle}
            />
            <CardText>Congratualations, you've finished reading {this.state.bookTitle}!</CardText>
            <CardActions style={{display: 'flex', flexWrap: 'wrap', margin: '0 auto', alignItems: 'center', justifyContent: 'center'}}>
              <Button className={style.sentence_swipe_button} label="Read from Beginning" raised primary onClick={this.onReadFromBeginningClick}/>
            </CardActions>
          </Card>
        </div>
      );

    } else {
      return (
        <div className={style.contents}>
          <ProgressBar type='circular'
                       mode='indeterminate'
                       multicolor/>
        </div>
      );
    }
  }

  render () {
    return (
      <div className={style.container}>
        <AppBar title='Berkeley Context Reader'>
          <AppBarButton icon="home" label="Main Menu" onClick={() => {
            this.props.router.push(`/`);
          }}/>
        </AppBar>
        {this.renderBookPage()}
      </div>
    );
  }

}

export default BookPage;