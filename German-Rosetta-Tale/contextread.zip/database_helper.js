'use strict';
module.change_code = 1;
var _ = require('lodash');
var dynasty = require('dynasty')({});

var DATA_TABLE_NAME = 'Books';

function BookHelper() {}
var BookTable = function() {
  return dynasty.table(DATA_TABLE_NAME);
};

BookHelper.prototype.createBookTable = function() {
  return dynasty.describe(DATA_TABLE_NAME)
    .catch(function(error) {
      return dynasty.create(DATA_TABLE_NAME, {
        key_schema: {
          hash: ['BookTitle', 'string'],
          range: ['SentenceIdx', number]
        }
      });
    });
};

BookHelper.prototype.readBookData = function(userId) {
  return BookTable().findAll(userId)
    .then(function(result) {
      return result;
    })
    .catch(function(error) {
      console.log(error);
    });
};

BookHelper.prototype.getBookTitles = function() {
  return BookTable().scan()
    .then(function(all) {
        var toReturn = [];
        for (var i = 0; i < all.length; i++) {
          if (!toReturn.includes(all[i]['BookTitle'])) {
            toReturn.push(all[i]['BookTitle']);
          }
        }
        toReturn.sort();
        return toReturn;
    });
}

module.exports = BookHelper;

