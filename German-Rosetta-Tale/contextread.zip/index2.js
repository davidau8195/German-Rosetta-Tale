const Alexa = require("alexa-sdk");
const RapidAPI = require('rapidapi-connect');
const rapid = new RapidAPI('RapidAPI-Translate', 'c848d833-8632-4485-841e-6d855dc05b4b');
var pos = require('pos');
var MAIN_PROMPT = 'Welcome to Context Reader! For a list of books, say list. To quit the application, say quit or exit.';

var Skill = require('alexa-app');
var skillService = new Skill.app('ContextReader');
var DatabaseHelper = require('./database_helper');
var databaseHelper = new DatabaseHelper();
var allEntries = {};
allEntries['Test'] = 'This is sentence one. This is sentence two. This is sentence three.'.split('\.');

//Session attributes
var currentDialog = 'Main';
var currentSentences;
var SentencesIndex = 0;

var handlers = {
  'Unhandled': function () {
    this.emit(':ask', 'I am sorry, I did not understand that. Say main menu to go back to the main menu.');
  },

  'LaunchRequest': function() {
    this.emit(':ask', MAIN_PROMPT);
  },

  'Translate': function() {
    const langCodes = {
        "German" : "de",
        "Dutch" : "nl",
        "English" : "en",
        "French" : "fr",
        "Italian" : "it",
        "Polish" : "pl",
        "Russian" : "ru",
        "Spanish" : "es"
    };

    var language = "German";
    var word = "Happy";
    var langCode = langCodes[language];

    rapid.call('GoogleTranslate', 'translateAutomatic', {
       'apiKey': 'AIzaSyAhkb5OAKTEvAdjDqrNyRRnLZD5g5k-QaA',
        'string': word,
        'targetLanguage': langCode

    }).on('success', (payload) => {
      this.emit(":ask", `${word} is ${payload} in ${language}`);
    }).on('error', (payload) => {
      this.emit(":ask", "Sorry, translation was unsuccessful..");
    });

  },

  'advanceSentenceIntent': function() {
    if (currentDialog === 'Sentences') {
      if (SentencesIndex == currentSentences.length - 1) {
        this.emit(":ask", currentSentences[SentencesIndex] 
            + 'The End. That was a pretty good story. Say start again to start again.'
            + 'Say quit or exit to go back to the main dialogue.');
        SentencesIndex = -1; //-1 means that we have just finished saying the final step.
      } else {
        this.emit(":ask", currentSentences[SentencesIndex]);
        SentencesIndex++;
      }
    } else {
      this.emit(":ask", 'You are not in the reading step right now. Say main menu to go back to the main menu.');
    }
  },

  'lastSentenceIntent': function() {
    if (SentencesIndex == -1) {
      this.emit(":ask", currentSentences[currentSentences.length - 1]
            + 'The End.'
            + 'Please say repeat in order to restart the story.'
            + 'Say quit or exit to go back to the main dialogue.');
    
    } else if (currentDialog === 'Sentences') {
      this.emit(":ask", currentSentences[--SentencesIndex]);
      SentencesIndex++;
    } else {
      this.emit(":ask", 'You are not in the reading step right now. Say main menu to go back to the main menu.');
    }
  },

  'getSentenceIntent': function() {
    if (!(currentDialog === 'Sentences')) {
      this.emit(":ask", 'There is no book loaded or we are not on the reading step yet. Say main menu to go back to the main menu.');
    } else {
      this.emit(":ask", currentSentences[0]);
      SentencesIndex = 1;
    }
  },

  'helpIntent': function() {
    var prompt = 'Here is a list of things you can say: '
        + 'Saying list will give you a list of books to read.'
        + 'Saying next will read the next sentence or translation if you are currently in the middle of reading a book. '
      + 'Saying menu at any time will stop what the program is doing and return to the main menu.'
      + 'Saying quit or exit will close the application'
      + 'To repeat what I have just said, say help.';
    this.emit(":ask", prompt);
  },

  'startIntent': function() {
    currentDialog = 'Main';
    SentencesIndex = 0;
    this.emit(":ask", MAIN_PROMPT);
  },

  'startAgainIntent': function() {
    if (currentDialog === 'Sentences' || SentencesIndex == -1) {
      SentencesIndex = 0;
      currentDialog = 'Sentences';
      this.emit(":ask", currentSentences[SentencesIndex]);
      SentencesIndex++;     
    } else if (currentDialog === 'Sentences') {
      SentencesIndex = 0;
      this.emit(":ask", currentSentences[SentencesIndex]);
      SentencesIndex++;
    } else {
      this.emit(":ask", 'Cannot start again, you are in the main dialogue. Say main menu to repeat options.');
    }
  },

  'getTestIntent': function() {
    currentSentences = allEntries['Test'];
    currentDialog = 'Sentences';
    this.emit(":ask", 'Test loaded sucessfully. Say sentences to start.');
  },

  'unknownIntent': function() {
    this.emit(":ask", 'I am sorry, I did not understand that. Say main menu to go back to the main menu.');
  },

  'quitIntent': function() {
    if (currentDialog === 'Main') {
      var prompt = 'Thank you for using Context Reader. Now quitting the app.';
      this.emit(":ask", prompt);
    } else {
      currentDialog = 'Main';
      SentencesIndex = 0;
      this.emit(":ask", MAIN_PROMPT);
    }
  }
};

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    // alexa.dynamoDBTableName = 'Books';
    alexa.registerHandlers(handlers);
    alexa.execute();
};