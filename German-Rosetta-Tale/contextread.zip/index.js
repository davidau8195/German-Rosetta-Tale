'use strict';
module.change_code = 1;
var _ = require('lodash');
var Skill = require('alexa-app');
// var pos = require('pos');
// const RapidAPI = new require('rapidapi-connect');
// const rapid = new RapidAPI('RapidAPI-Translate', 'c848d833-8632-4485-841e-6d855dc05b4b');
// const GoogleAPIKey = 'AIzaSyAhkb5OAKTEvAdjDqrNyRRnLZD5g5k-QaA';
// var RECIPE_SESSION_KEY = 'context_reader';
var skillService = new Skill.app('ContextReader');
var DatabaseHelper = require('./database_helper');
var databaseHelper = new DatabaseHelper();
var MAIN_PROMPT = 'Welcome to Context Reader! For a list of books, say list. '
                  + 'To choose whether you want to replace one or two words, '
                  + 'Either say replace one word OR say replace two words. '
                  + 'To set the speed of the reader, say either, '
                  + 'Set speed to slow or say set speed to normal. '
                  + 'To quit the application, say quit or exit. ';

//Session attributes
var currentDialog = 'Main';
var currentSentences;
var SentencesIndex = 0;
var speed = 'Normal';
var numberOfReplacements = 1;

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
}

skillService.pre = function(request, response, type) {
  databaseHelper.createBookTable();
};

skillService.launch(function(request, response) {
  response.say(MAIN_PROMPT);
  response.shouldEndSession(false);
  response.send();
});

skillService.intent('slowSpeedIntent',
  function(request, response) {
    speed = 'Slow';
    response.say('I have set the speed to slow. Say help for help. ')
    response.shouldEndSession(false);
    response.send();
    return false;
  }
);

skillService.intent('normalSpeedIntent',
  function(request, response) {
    speed = 'Normal';
    response.say('I have set the speed to normal. Say help for help. ')
    response.shouldEndSession(false);
    response.send();
    return false;
  }
);

skillService.intent('advanceSentenceIntent',
  function(request, response) {
    if (currentDialog === 'Sentences') {
      if (SentencesIndex == currentSentences.length - 1) {
        var replacementSentence = "";
        var wordTranslations = "";
        if (numberOfReplacements == 2) {
            replacementSentence = currentSentences[SentencesIndex]['TwoWordsReplaced'];
            wordTranslations = currentSentences[SentencesIndex]['WordTwo'] + " " + currentSentences[SentencesIndex]['WordThree'];
        } else {
            replacementSentence = currentSentences[SentencesIndex]['OneWordReplaced'];
            wordTranslations = currentSentences[SentencesIndex]['WordOne'];
        }
        var toSay = currentSentences[SentencesIndex]['EnglishSentence']
            + " " + replacementSentence
            + " " + wordTranslations
            + ' The End. That was a pretty good story. Say start again to start again. '
            + 'Say main menu to go back to the main dialogue.';
        if (speed === 'Slow') {
          toSay = toSay.split(' ').join('<break time=\"0.6s\"/> ');
        }
        response.say(toSay);
        SentencesIndex = -1; //-1 means that we have just finished saying the final step.
        response.shouldEndSession(false);
        response.send();
        return false;
      }
      var replacementSentence = "";
      var wordTranslations = "";
      if (numberOfReplacements == 2) {
          replacementSentence = currentSentences[SentencesIndex]['TwoWordsReplaced'];
          wordTranslations = currentSentences[SentencesIndex]['WordTwo'] + " " + currentSentences[SentencesIndex]['WordThree'];
      } else {
          replacementSentence = currentSentences[SentencesIndex]['OneWordReplaced'];
          wordTranslations = currentSentences[SentencesIndex]['WordOne'];
      }
      var toSay = currentSentences[SentencesIndex]['EnglishSentence']
          + " " + replacementSentence
          + " " + wordTranslations;
      if (speed === 'Slow') {
        toSay = toSay.split(' ').join('<break time=\"0.6s\"/> ');
      }
      response.say(toSay);
      SentencesIndex++;
      response.shouldEndSession(false);
      response.send();
      return false;
    } else {
      response.say('You are not in the reading step right now. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
      return false;
    }
  }
);

skillService.intent('getGameOfThronesIntent',
  function(request, response) {
    databaseHelper.readBookData('A Game of Thrones').then(function(result) {
      currentSentences = result;
      currentDialog = 'Sentences';
      return 'Loaded sucessfully. Say sentences to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false);
      response.send();
    });
    return false;
  }
);

skillService.intent('getTheBookThiefIntent',
  function(request, response) {
    databaseHelper.readBookData('The Book Thief').then(function(result) {
      currentSentences = result;
      currentDialog = 'Sentences';
      return 'Loaded sucessfully. Say sentences to start.';
    }).then(function(prompt) {
      response.say(prompt);
      response.shouldEndSession(false);
      response.send();
    });
    return false;
  }
);

skillService.intent('listBooksIntent',
  function(request, response) {
    databaseHelper.getBookTitles().then(function(result) {
      var str = "";
      for (var i = 0; i < result.length; i++) {
        str += result[i] + ". ";
      }
      response.say('The list of available books is as follows: ' + str);
      response.shouldEndSession(false);
      response.send();
    });
    return false;
  }
);

// David's Functions // David's Functions // David's Functions
skillService.intent('quickStartIntent',
  function(request, response) {
    databaseHelper.getBookTitles().then(function(results) {
      var selectedBook = results[getRandomInt(0, results.length)];
      databaseHelper.readBookData(selectedBook).then(function(result) {
        currentSentences = result;
        currentDialog = 'Sentences';
      });
      response.say('Loaded sucessfully. Say sentences to start.');
      response.shouldEndSession(false);
      response.send();
    });
    return false;
  }
);

skillService.intent('replaceOneWordIntent',
  function(request, response) {
    numberOfReplacements = 1;
    response.say('I will replace one word in each sentence for you. Say help for help. ');
    response.shouldEndSession(false);
    response.send();
    return false;
  }
);


skillService.intent('replaceTwoWordsIntent',
  function(request, response) {
    numberOfReplacements = 2;
    response.say('I will replace two words in each sentence for you. Say help for help. ');
    response.shouldEndSession(false);
    response.send();
    return false;
  }
);
// David's Functions // David's Functions // David's Functions


skillService.intent('lastSentenceIntent',
  function(request, response) {
    if (SentencesIndex == -1) {
      // Word Replacement Policy
      var replacementSentence = "";
      var wordTranslations = "";
      if (numberOfReplacements == 2) {
          replacementSentence = currentSentences[currentSentences.length - 1]['TwoWordsReplaced'];
          wordTranslations = currentSentences[currentSentences.length - 1]['WordTwo'] + " " + currentSentences[currentSentences.length - 1]['WordThree'];
      } else {
          replacementSentence = currentSentences[currentSentences.length - 1]['OneWordReplaced'];
          wordTranslations = currentSentences[currentSentences.length - 1]['WordOne'];
      }
      var toSay = currentSentences[currentSentences.length - 1]['EnglishSentence']
          + " " + replacementSentence
          + " " + wordTranslations
            + ' The End. '
            + 'Please say repeat in order to restart the story. '
            + 'Say quit or exit to go back to the main dialogue.';
      if (speed === 'Slow') {
        toSay = toSay.split(' ').join('<break time=\"0.6s\"/> ');
      }  
      response.say(toSay);
      response.shouldEndSession(false);
      response.send();
      return false;      
    }
    if (currentDialog === 'Sentences') {
      SentencesIndex--;
      var replacementSentence = "";
      var wordTranslations = "";
      if (numberOfReplacements == 2) {
          replacementSentence = currentSentences[SentencesIndex]['TwoWordsReplaced'];
          wordTranslations = currentSentences[SentencesIndex]['WordTwo'] + " " + currentSentences[SentencesIndex]['WordThree'];
      } else {
          replacementSentence = currentSentences[SentencesIndex]['OneWordReplaced'];
          wordTranslations = currentSentences[SentencesIndex]['WordOne'];
      }
      var toSay = currentSentences[SentencesIndex]['EnglishSentence']
          + " " + replacementSentence
          + " " + wordTranslations;
      if (speed === 'Slow') {
        toSay = toSay.split(' ').join('<break time=\"0.6s\"/> ');
      } 
      response.say(toSay);
      SentencesIndex++;
      response.shouldEndSession(false);
      response.send();
      // return false;
    } else {
      response.say('You are not in the reading step right now. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
      return false;
    }
  }
);

skillService.intent('getSentenceIntent',
  function(request, response) {
    if (!(currentDialog === 'Sentences')) {
      response.say('There is no book loaded or we are not on the reading step yet. Say main menu to go back to the main menu.');
      response.shouldEndSession(false);
      response.send();
      return false;
    }
    var replacementSentence = "";
    var wordTranslations = "";
    if (numberOfReplacements == 2) {
        replacementSentence = currentSentences[0]['TwoWordsReplaced'];
        wordTranslations = currentSentences[0]['WordTwo'] + " " + currentSentences[0]['WordThree'];
    } else {
        replacementSentence = currentSentences[0]['OneWordReplaced'];
        wordTranslations = currentSentences[0]['WordOne'];
    }
    var toSay = currentSentences[0]['EnglishSentence']
        + " " + replacementSentence
        + " " + wordTranslations;
    if (speed === 'Slow') {
      toSay = toSay.split(' ').join('<break time=\"0.6s\"/> ');
    } 
    response.say(toSay);
    SentencesIndex = 1;
    response.shouldEndSession(false);
    response.send();
    return false;
  }
);


skillService.intent('helpIntent',
  function(request, response) {
    var prompt = 'Here is a list of things you can say: '
        + 'Saying list will give you a list of books to read.'
        + 'Saying next will read the next sentence or translation if you are currently in the middle of reading a book. '
        + 'Saying menu at any time will stop what the program is doing and return to the main menu. '
        + 'Saying set speed to slow will set the reading speed to slow. Saying set speed to normal will set the reading speed to normal. '
        + 'Saying quit or exit will close the application. '
        + 'To repeat what I have just said, say help.';
    response.say(prompt);
    response.shouldEndSession(false);
    response.send();
    // return false;
  }
);

skillService.intent('startIntent',
  function(request, response) {
    currentDialog = 'Main';
    SentencesIndex = 0;
    SentencesIndex = 0;
    response.say(MAIN_PROMPT);
    response.shouldEndSession(false);
    response.send();
  }
);

skillService.intent('startAgainIntent',
  function(request, response) {
    if (currentDialog === 'Sentences' || SentencesIndex == -1) {
      SentencesIndex = 0;
      currentDialog = 'Sentences';
      var replacementSentence = "";
      var wordTranslations = "";
      if (numberOfReplacements == 2) {
          replacementSentence = currentSentences[SentencesIndex]['TwoWordsReplaced'];
          wordTranslations = currentSentences[SentencesIndex]['WordTwo'] + " " + currentSentences[SentencesIndex]['WordThree'];
      } else {
          replacementSentence = currentSentences[SentencesIndex]['OneWordReplaced'];
          wordTranslations = currentSentences[SentencesIndex]['WordOne'];
      }
      var toSay = currentSentences[SentencesIndex]['EnglishSentence']
          + " " + replacementSentence
          + " " + wordTranslations;
      if (speed === 'Slow') {
        toSay = toSay.split(' ').join('<break time=\"0.6s\"/> ');
      }                                                  
      response.say(toSay);
      SentencesIndex++;
      response.shouldEndSession(false);
      response.send();
      return false;   
    }
    // else if (currentDialog === 'Sentences') {
    //   SentencesIndex = 0;
    //   var toSay = currentSentences[SentencesIndex]['EnglishSentence'];
    //   if (speed === 'Slow') {
    //     toSay = toSay.split(' ').join('<break time=\"0.6s\"/> ');
    //   }                                                  
    //   response.say(toSay);
    //   SentencesIndex++;
    //   response.send();
    // }
    else {
      response.say('Cannot start again, you are in the main dialogue. Say main menu to repeat options.');
      response.shouldEndSession(false);
      response.send();
      // return false;        
    }
  }
);

skillService.intent('unknownIntent',
  function(request, response) {
    response.say('I am sorry, I did not understand that. Say main menu to go back to the main menu.');
    response.send();
  }
);

skillService.intent('quitIntent',
  function(request, response) {
    if (currentDialog === 'Main') {
      var prompt = 'Thank you for using Context Reader. Now quitting the app.';
      response.say(prompt);
      response.shouldEndSession(true);
    } else {
      currentDialog = 'Main';
      SentencesIndex = 0;
      SentencesIndex = 0;
      response.say(MAIN_PROMPT);
      response.shouldEndSession(false);
      response.send();
    }
  }
);

module.exports = skillService;
