var RapidAPI = require('rapidapi-connect');
var rapid = new RapidAPI('RapidAPI-Translate', 'c848d833-8632-4485-841e-6d855dc05b4b');
var DatabaseHelper = require('./database_helper');
var databaseHelper = new DatabaseHelper();
databaseHelper.createBookTable();

var GoogleAPIKey = 'AIzaSyAhkb5OAKTEvAdjDqrNyRRnLZD5g5k-QaA';

var langCodes = {
    "German" : "de",
    "Dutch" : "nl",
    "English" : "en",
    "French" : "fr",
    "Italian" : "it",
    "Polish" : "pl",
    "Russian" : "ru",
    "Spanish" : "es"
};
var source = 'What is this? ';
var lang = 'German';
var langCode = langCodes[lang];

//Call RapidAPI
rapid.call('GoogleTranslate', 'translateAutomatic', {
    string : source,
    apiKey: GoogleAPIKey,
    targetLanguage: langCode
})
    .on('error', (err) => {
        console.error(err);
    })
    .on ('success', (payload) => {
        console.log(`${payload}`);
    });

databaseHelper.getBookTitles().then(function(result) {
  var str = "";
  for (var i = 0; i < result.length; i++) {
    str += result[0];
  }
  console.log(str);
});